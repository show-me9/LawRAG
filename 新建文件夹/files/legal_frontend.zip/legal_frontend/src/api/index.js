import axios from 'axios'
import { ElMessage } from 'element-plus'

const http = axios.create({
  baseURL: '/api',
  timeout: 60000,
})

http.interceptors.response.use(
  res => res.data,
  err => {
    const msg = err.response?.data?.detail || err.message || '请求失败'
    ElMessage.error(msg)
    return Promise.reject(err)
  }
)

// ── session_id 管理 ───────────────────────────────────────
// 每次打开浏览器生成一个 session_id，存入 sessionStorage
// 刷新页面保持同一会话，关闭标签页后下次自动生成新的
function getSessionId() {
  let sid = sessionStorage.getItem('legal_session_id')
  if (!sid) {
    sid = crypto.randomUUID()
    sessionStorage.setItem('legal_session_id', sid)
  }
  return sid
}

export const getSessionId_ = getSessionId

// ── 健康检查 ──────────────────────────────────────────────
export const getHealth = () => http.get('/health')

// ── 文档管理 ──────────────────────────────────────────────
export const getDocuments    = ()         => http.get('/documents')
export const uploadDocument  = (formData) => http.post('/documents/upload', formData, {
  headers: { 'Content-Type': 'multipart/form-data' },
  timeout: 300000,
})
export const getIngestStatus = (filename) =>
  http.get(`/documents/upload/status/${encodeURIComponent(filename)}`)
export const deleteDocument  = (filename) =>
  http.delete(`/documents/${encodeURIComponent(filename)}`)

// ── 智能问答 ──────────────────────────────────────────────
export const sendChat = (question) =>
  http.post('/chat', { question, session_id: getSessionId() })

export const clearChat = (clearLongTerm = false) =>
  http.post('/chat/clear', {
    session_id:      getSessionId(),
    clear_long_term: clearLongTerm,
  })

export const closeSession = () =>
  http.delete(`/chat/session/${getSessionId()}`)

export const getMemory = () =>
  http.get(`/chat/memory/${getSessionId()}`)

// ── 设置 ─────────────────────────────────────────────────
export const getSettings    = ()     => http.get('/settings')
export const updateSettings = (data) => http.post('/settings', data)
export const testConnection = ()     => http.get('/settings/test-connection')
