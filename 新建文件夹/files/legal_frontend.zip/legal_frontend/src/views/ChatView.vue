<template>
  <div class="chat-view">
    <!-- 顶部栏 -->
    <div class="chat-header">
      <span class="page-title">智能问答</span>
      <div class="header-actions">
        <!-- 长期记忆状态 -->
        <el-tooltip content="查看用户画像（长期记忆）" placement="bottom">
          <el-button size="small" plain :icon="User" @click="showMemoryDialog = true">
            用户画像
          </el-button>
        </el-tooltip>
        <!-- 清空对话 -->
        <el-dropdown @command="handleClearCommand">
          <el-button size="small" plain :icon="Delete">
            清空对话 <el-icon class="el-icon--right"><ArrowDown /></el-icon>
          </el-button>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="short">仅清空当前对话</el-dropdown-item>
              <el-dropdown-item command="all" divided>同时清空用户画像</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>

    <!-- 消息列表 -->
    <div class="message-list" ref="listRef">
      <div v-if="messages.length === 0" class="empty-state">
        <el-icon class="empty-icon"><ChatLineRound /></el-icon>
        <p class="empty-title">您好，请输入法律问题</p>
        <p class="empty-sub">系统将基于已摄入的法律文档为您解答，并标注引用条文</p>
      </div>

      <template v-for="(msg, idx) in messages" :key="idx">
        <!-- 用户消息 -->
        <div v-if="msg.role === 'user'" class="msg-row msg-user">
          <div class="bubble bubble-user">{{ msg.content }}</div>
        </div>

        <!-- 助手消息 -->
        <div v-else class="msg-row msg-assistant">
          <div class="avatar-icon"><el-icon><Memo /></el-icon></div>
          <div class="bubble-wrap">
            <div class="bubble bubble-assistant" v-html="renderAnswer(msg.content)"></div>

            <!-- 引用条文 -->
            <div v-if="msg.sources?.length" class="sources">
              <div class="sources-title">
                <el-icon><Document /></el-icon> 引用条文
              </div>
              <div v-for="(src, si) in msg.sources" :key="si" class="source-item">
                <span class="source-tag">[{{ si + 1 }}]</span>
                <span class="source-citation">{{ src.citation }}</span>
                <el-tooltip :content="src.snippet" placement="top" :show-after="300">
                  <el-icon class="source-eye"><View /></el-icon>
                </el-tooltip>
              </div>
            </div>

            <!-- 改写查询 -->
            <div
              v-if="msg.rewritten_query && msg.rewritten_query !== messages[idx-1]?.content"
              class="rewritten"
            >
              <el-icon><Search /></el-icon>
              检索查询：{{ msg.rewritten_query }}
            </div>
          </div>
        </div>
      </template>

      <!-- 加载中 -->
      <div v-if="loading" class="msg-row msg-assistant">
        <div class="avatar-icon"><el-icon><Memo /></el-icon></div>
        <div class="bubble bubble-assistant bubble-loading">
          <span class="dot"></span><span class="dot"></span><span class="dot"></span>
        </div>
      </div>
    </div>

    <!-- 输入区 -->
    <div class="input-area">
      <el-input
        v-model="inputText"
        type="textarea"
        :rows="3"
        placeholder="请输入您的法律问题，按 Ctrl+Enter 发送..."
        resize="none"
        :disabled="loading"
        @keydown.ctrl.enter="handleSend"
      />
      <el-button
        type="primary"
        :icon="Promotion"
        :loading="loading"
        :disabled="!inputText.trim()"
        @click="handleSend"
        class="send-btn"
      >发送</el-button>
    </div>

    <!-- 长期记忆对话框 -->
    <el-dialog v-model="showMemoryDialog" title="用户画像（长期记忆）" width="480px">
      <div v-if="memoryData" class="memory-display">
        <div class="memory-item">
          <div class="memory-label">用户背景</div>
          <div class="memory-value">{{ memoryData.background || '暂未识别' }}</div>
        </div>
        <div class="memory-item">
          <div class="memory-label">回答偏好</div>
          <div class="memory-value">{{ memoryData.preferences || '暂未识别' }}</div>
        </div>
        <div class="memory-item">
          <div class="memory-label">其他信息</div>
          <div class="memory-value">{{ memoryData.notes || '暂无' }}</div>
        </div>
        <p class="memory-tip">长期记忆在每轮对话结束后自动更新，跨会话持久保存。</p>
      </div>
      <div v-else class="memory-empty">加载中...</div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, nextTick, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Delete, Promotion, User, ArrowDown } from '@element-plus/icons-vue'
import { sendChat, clearChat, getMemory } from '@/api'

const messages       = ref([])
const inputText      = ref('')
const loading        = ref(false)
const listRef        = ref(null)
const showMemoryDialog = ref(false)
const memoryData     = ref(null)

// 打开对话框时加载长期记忆
watch(showMemoryDialog, async (val) => {
  if (val) {
    try {
      const res = await getMemory()
      memoryData.value = res.long_term
    } catch {
      memoryData.value = { background: '', preferences: '', notes: '' }
    }
  }
})

function renderAnswer(text) {
  return text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/【(.+?)】/g, '<span class="cite-tag">【$1】</span>')
    .replace(/\n/g, '<br>')
}

async function scrollToBottom() {
  await nextTick()
  if (listRef.value) listRef.value.scrollTop = listRef.value.scrollHeight
}

async function handleSend() {
  const q = inputText.value.trim()
  if (!q || loading.value) return

  messages.value.push({ role: 'user', content: q })
  inputText.value = ''
  loading.value = true
  await scrollToBottom()

  try {
    const res = await sendChat(q)
    messages.value.push({
      role:            'assistant',
      content:         res.answer,
      sources:         res.sources,
      rewritten_query: res.rewritten_query,
    })
  } catch {
    messages.value.push({ role: 'assistant', content: '请求失败，请检查服务状态后重试。', sources: [] })
  } finally {
    loading.value = false
    await scrollToBottom()
  }
}

async function handleClearCommand(cmd) {
  if (messages.value.length === 0 && cmd === 'short') return
  const confirmMsg = cmd === 'all'
    ? '确认清空当前对话及用户画像？'
    : '确认清空当前对话记录？'

  await ElMessageBox.confirm(confirmMsg, '提示', {
    confirmButtonText: '确认', cancelButtonText: '取消', type: 'warning',
  })

  const clearLongTerm = cmd === 'all'
  await clearChat(clearLongTerm)
  messages.value = []
  ElMessage.success(clearLongTerm ? '对话与用户画像已清空' : '对话已清空')
}
</script>

<style scoped>
.chat-view { display:flex; flex-direction:column; height:100%; background:var(--color-bg); }

.chat-header {
  display:flex; align-items:center; justify-content:space-between;
  padding:14px 24px; background:var(--color-bg-card);
  border-bottom:1px solid var(--color-border); flex-shrink:0;
}
.page-title { font-size:15px; font-weight:600; }
.header-actions { display:flex; gap:8px; }

.message-list { flex:1; overflow-y:auto; padding:24px; display:flex; flex-direction:column; gap:20px; }

.empty-state { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; padding:60px 0; }
.empty-icon  { font-size:48px; color:#c0c4cc; }
.empty-title { font-size:15px; color:var(--color-text-second); }
.empty-sub   { font-size:13px; color:var(--color-text-hint); }

.msg-row      { display:flex; gap:12px; max-width:820px; }
.msg-user     { align-self:flex-end; flex-direction:row-reverse; }
.msg-assistant{ align-self:flex-start; }

.avatar-icon {
  width:34px; height:34px; border-radius:8px;
  background:var(--color-primary); color:#fff;
  display:flex; align-items:center; justify-content:center;
  font-size:16px; flex-shrink:0; margin-top:2px;
}

.bubble { padding:12px 16px; border-radius:12px; line-height:1.7; font-size:14px; word-break:break-word; }
.bubble-user      { background:var(--color-primary); color:#fff; border-bottom-right-radius:4px; }
.bubble-assistant { background:var(--color-bg-card); border:1px solid var(--color-border); border-bottom-left-radius:4px; box-shadow:var(--shadow-sm); }

:deep(.cite-tag) { color:var(--color-primary-light); font-weight:500; }

.bubble-loading { display:flex; align-items:center; gap:6px; padding:14px 18px; }
.dot { width:7px; height:7px; border-radius:50%; background:#c0c4cc; animation:bounce .9s infinite; }
.dot:nth-child(2){ animation-delay:.2s; }
.dot:nth-child(3){ animation-delay:.4s; }
@keyframes bounce { 0%,60%,100%{ transform:translateY(0); } 30%{ transform:translateY(-6px); } }

.bubble-wrap { display:flex; flex-direction:column; gap:8px; }
.sources { background:#f8f9fb; border:1px solid var(--color-border); border-radius:8px; padding:10px 12px; display:flex; flex-direction:column; gap:6px; }
.sources-title { display:flex; align-items:center; gap:5px; font-size:12px; font-weight:600; color:var(--color-text-second); margin-bottom:2px; }
.source-item { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--color-text-second); }
.source-tag { color:var(--color-primary-light); font-weight:600; flex-shrink:0; }
.source-citation { flex:1; }
.source-eye { cursor:pointer; color:#c0c4cc; }
.source-eye:hover { color:var(--color-primary-light); }
.rewritten { display:flex; align-items:center; gap:5px; font-size:12px; color:var(--color-text-hint); padding:4px 0; }

.input-area { padding:16px 24px; background:var(--color-bg-card); border-top:1px solid var(--color-border); display:flex; gap:12px; align-items:flex-end; flex-shrink:0; }
.input-area :deep(.el-textarea__inner) { border-radius:var(--radius); font-size:14px; line-height:1.6; resize:none; }
.send-btn { height:72px; padding:0 22px; flex-shrink:0; }

/* 长期记忆对话框 */
.memory-display { display:flex; flex-direction:column; gap:14px; }
.memory-item { display:flex; flex-direction:column; gap:4px; }
.memory-label { font-size:12px; font-weight:600; color:var(--color-text-hint); }
.memory-value { font-size:14px; color:var(--color-text-primary); background:#f8f9fb; border-radius:6px; padding:8px 12px; min-height:36px; }
.memory-tip   { font-size:12px; color:var(--color-text-hint); margin-top:4px; }
.memory-empty { text-align:center; color:var(--color-text-hint); padding:20px; }
</style>
